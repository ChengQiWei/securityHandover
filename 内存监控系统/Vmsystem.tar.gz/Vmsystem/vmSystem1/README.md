# Dependent

- sudo apt-get install python-qt4
- sudo pip install kvm
- sudo apt-get install libcanberra-gtk-module

# Configure

- add Environment variables
 - QT_X11_NO_MITSHM = 1


# 备注    

代码同/home/ubuntu-sqq/Projects/vmSystem
新增本地监控和docker监控功能