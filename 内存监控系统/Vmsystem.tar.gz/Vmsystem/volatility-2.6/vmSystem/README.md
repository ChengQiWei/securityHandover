# Dependent

- sudo apt-get install python-qt4
- sudo pip install kvm
- sudo apt-get install libcanberra-gtk-module

# Configure

- add Environment variables
 - QT_X11_NO_MITSHM = 1
