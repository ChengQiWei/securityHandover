# TPM2 TSS Interfaces for SWIG

[SWIG](http://www.swig.org/) is a binding generator which can use these
interface files to enable use of the TPM2 TSS repos from other languages.
Currently this repo provides interface files for accessing

- The Enhanced System API (ESAPI / `Esys_`)
- Dynamically loaded TCTIs via TCTILDR
