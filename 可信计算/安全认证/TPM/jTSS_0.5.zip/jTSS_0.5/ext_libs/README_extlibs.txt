This directory is for third party libraries
which are required for some optional jTSS features.

Please consult the jTSS documentation for more details.
